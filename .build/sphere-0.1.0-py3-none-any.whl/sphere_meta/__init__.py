"""Meta package placeholder.

This module exists so the meta package can be built as a wheel. It intentionally
does not provide runtime functionality. The meta distribution's purpose is to
aggregate runtime dependencies only.
"""

__all__ = []
